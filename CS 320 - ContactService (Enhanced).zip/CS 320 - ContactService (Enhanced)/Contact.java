package module3;

/**
 * Represents a contact in the contact service.
 */
public class Contact {
    private final String contactID;
    private String firstName;
    private String lastName;
    private String phone;
    private String emailAddress;

    public Contact(String contactID, String firstName, String lastName,
                   String phone, String emailAddress) {
        validateContactID(contactID);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhone(phone);
        validateEmailAddress(emailAddress);

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.emailAddress = emailAddress;
    }

    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setFirstName(String firstName) {
        validateFirstName(firstName);
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        validateLastName(lastName);
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    public void setEmailAddress(String emailAddress) {
        validateEmailAddress(emailAddress);
        this.emailAddress = emailAddress;
    }

    private static void validateContactID(String contactID) {
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
    }

    private static void validateFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
    }

    private static void validateLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
    }

    private static void validatePhone(String phone) {
        if (phone == null || phone.length() != 10) {
            throw new IllegalArgumentException("Invalid phone number");
        }
    }

    private static void validateEmailAddress(String emailAddress) {
        if (emailAddress == null || emailAddress.length() > 30) {
            throw new IllegalArgumentException("Invalid email address");
        }
    }
}
