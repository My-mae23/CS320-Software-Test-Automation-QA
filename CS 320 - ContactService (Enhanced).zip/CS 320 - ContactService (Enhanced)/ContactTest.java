package module3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
    private Contact contact;

    @BeforeEach
    void setUp() {
        contact = new Contact("1", "Myra", "Mae", "1234567890", "myra@example.com");
    }

    @Test
    void testGetContactID() {
        assertEquals("1", contact.getContactID());
    }

    @Test
    void testGetFirstName() {
        assertEquals("Myra", contact.getFirstName());
    }

    @Test
    void testGetLastName() {
        assertEquals("Mae", contact.getLastName());
    }

    @Test
    void testGetPhone() {
        assertEquals("1234567890", contact.getPhone());
    }

    @Test
    void testGetEmailAddress() {
        assertEquals("myra@example.com", contact.getEmailAddress());
    }

    @Test
    void testSetFirstName() {
        contact.setFirstName("Sheila");
        assertEquals("Sheila", contact.getFirstName());
    }

    @Test
    void testSetLastName() {
        contact.setLastName("Zamora");
        assertEquals("Zamora", contact.getLastName());
    }

    @Test
    void testSetPhone() {
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    void testSetEmailAddress() {
        contact.setEmailAddress("myra.henderson@example.com");
        assertEquals("myra.henderson@example.com", contact.getEmailAddress());
    }

    @Test
    void testInvalidContactID() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "Myra", "Mae", "1234567890", "myra@example.com"));
    }

    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("2", "Myra", "Mae", "123", "myra@example.com"));
    }
}
