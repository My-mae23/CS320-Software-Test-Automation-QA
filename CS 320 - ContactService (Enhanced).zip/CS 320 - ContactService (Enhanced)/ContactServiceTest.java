package module3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    private Contact createContact(String id) {
        return new Contact(id, "Myra", "Mae", "1234567890", "myra@example.com");
    }

    @Test
    void testAddContact() {
        Contact contact = createContact("1");
        contactService.addContact(contact);

        assertEquals(1, contactService.getAllContacts().size());
        assertSame(contact, contactService.getContact("1"));
    }

    @Test
    void testDuplicateContactIDIsRejected() {
        contactService.addContact(createContact("1"));

        assertThrows(IllegalArgumentException.class,
                () -> contactService.addContact(createContact("1")));
    }

    @Test
    void testDeleteContact() {
        contactService.addContact(createContact("1"));

        contactService.deleteContact("1");

        assertEquals(0, contactService.getAllContacts().size());
        assertNull(contactService.getContact("1"));
    }

    @Test
    void testDeleteMissingContactIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.deleteContact("missing"));
    }

    @Test
    void testGetContactByIdUsesHashMapLookup() {
        Contact first = createContact("1");
        Contact second = createContact("2");
        Contact target = createContact("1003");

        contactService.addContact(first);
        contactService.addContact(second);
        contactService.addContact(target);

        Contact retrievedContact = contactService.getContact("1003");

        assertSame(target, retrievedContact);
        assertEquals("1003", retrievedContact.getContactID());
    }

    @Test
    void testUpdateContact() {
        contactService.addContact(createContact("1"));

        contactService.updateContact("1", "Sheila", "Zamora", "0987654321", "myra.henderson@example.com");

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Sheila", updatedContact.getFirstName());
        assertEquals("Zamora", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("myra.henderson@example.com", updatedContact.getEmailAddress());
    }

    @Test
    void testUpdateContactAllowsPartialUpdate() {
        contactService.addContact(createContact("1"));

        contactService.updateContact("1", "Sheila", null, null, null);

        Contact updatedContact = contactService.getContact("1");
        assertEquals("Sheila", updatedContact.getFirstName());
        assertEquals("Mae", updatedContact.getLastName());
        assertEquals("1234567890", updatedContact.getPhone());
        assertEquals("myra@example.com", updatedContact.getEmailAddress());
    }

    @Test
    void testUpdateMissingContactIsRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateContact("missing", "Sheila", null, null, null));
    }

    @Test
    void testInvalidUpdatedValueIsRejected() {
        contactService.addContact(createContact("1"));

        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateContact("1", null, null, "123", null));
    }

    @Test
    void testReturnedContactCollectionIsReadOnly() {
        contactService.addContact(createContact("1"));

        assertThrows(UnsupportedOperationException.class,
                () -> contactService.getAllContacts().clear());
    }
}
