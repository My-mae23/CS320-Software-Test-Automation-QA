# ContactService - Algorithms and Data Structures Enhancement

## Enhancement implemented
The ContactService now uses a `HashMap<String, Contact>` where each contact ID is the key and the corresponding Contact object is the value.

This design supports average-case O(1) lookup, insertion, and deletion by contact ID. The original contact-management functionality is preserved while the internal data structure is explicitly aligned with the service's primary key-based operations.

## Testing improvements
The unit tests were updated to match the actual public API of `Contact` and `ContactService`. Additional tests verify:

- Adding contacts
- Duplicate contact IDs
- Retrieving contacts by ID
- Deleting contacts
- Updating contacts
- Partial updates
- Missing contact IDs
- Invalid values
- Read-only access to the contact collection

## Design trade-off
A HashMap uses additional memory for its hash table and entries. The trade-off is faster average-case key-based retrieval compared with a sequential search through a list.

## Important note
The original project supplied in the archive already contained a HashMap in ContactService.java. Therefore, this enhancement makes the data-structure choice more explicit, strengthens the implementation around that structure, and adds tests that demonstrate and protect the expected behavior. It is more accurate to describe the change as refining and validating the HashMap-based design rather than replacing a List with a HashMap from scratch.
