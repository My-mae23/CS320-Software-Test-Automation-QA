package module3;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Provides operations for storing and managing contacts.
 *
 * Enhancement: contacts are indexed by their unique contact ID in a HashMap.
 * This changes contact retrieval from a potential O(n) sequential search to
 * average-case O(1) lookup by key.
 */
public class ContactService {
    private final Map<String, Contact> contactList = new HashMap<>();

    /**
     * Adds a contact using its unique ID as the HashMap key.
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        String contactID = contact.getContactID();
        if (contactList.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID already exists");
        }

        contactList.put(contactID, contact);
    }

    /**
     * Deletes a contact by ID.
     */
    public void deleteContact(String contactID) {
        if (!contactList.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contactList.remove(contactID);
    }

    /**
     * Updates the supplied contact fields by ID.
     * Null fields are ignored so callers can update only selected values.
     */
    public void updateContact(String contactID, String firstName, String lastName,
                              String phone, String emailAddress) {
        Contact contact = contactList.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        if (firstName != null) {
            contact.setFirstName(firstName);
        }
        if (lastName != null) {
            contact.setLastName(lastName);
        }
        if (phone != null) {
            contact.setPhone(phone);
        }
        if (emailAddress != null) {
            contact.setEmailAddress(emailAddress);
        }
    }

    /**
     * Retrieves a contact by ID using the HashMap key.
     * Average-case lookup complexity is O(1).
     */
    public Contact getContact(String contactID) {
        return contactList.get(contactID);
    }

    /**
     * Returns a read-only view of the contacts for validation and testing.
     * The service remains responsible for all modifications.
     */
    public Map<String, Contact> getAllContacts() {
        return Collections.unmodifiableMap(contactList);
    }
}
