package module5;

import java.util.Date;

public class Appointment {
    // Final variables to store appointment details
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    // Constructor to initialize the appointment object
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Check if appointmentId is valid (not null and within length limit)
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        // Check if appointmentDate is valid (not null and not in the past)
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        // Check if description is valid (not null and within length limit)
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        // Assign values to the final variables
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getter method for appointmentId
    public String getAppointmentId() {
        return appointmentId;
    }

    // Getter method for appointmentDate
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Getter method for description
    public String getDescription() {
        return description;
    }
}
