package module5;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // HashMap to store appointments with their IDs as keys
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Method to add an appointment to the service
    public void addAppointment(Appointment appointment) {
        // Check if the appointment ID already exists
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        // Add the appointment to the map
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Method to delete an appointment from the service
    public void deleteAppointment(String appointmentId) {
        // Check if the appointment ID exists in the map
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        // Remove the appointment from the map
        appointments.remove(appointmentId);
    }

    // Method to retrieve an appointment by its ID
    public Appointment getAppointment(String appointmentId) {
        // Return the appointment associated with the ID
        return appointments.get(appointmentId);
    }
}
