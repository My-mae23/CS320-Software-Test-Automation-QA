package module5;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class AppointmentServiceTest {

    private AppointmentService appointmentService;
    private Appointment appointment1;
    private Appointment appointment2;

    // This method runs before each test case to set up the initial conditions
    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService(); // Initialize the service
        appointment1 = new Appointment("1", "Doctor's appointment", "2024-12-01T10:00"); // Create first appointment
        appointment2 = new Appointment("2", "Dentist appointment", "2024-12-02T11:00"); // Create second appointment
    }

    // Test case for adding an appointment
    @Test
    public void testAddAppointment() {
        appointmentService.addAppointment(appointment1); // Add the first appointment
        assertEquals(appointment1, appointmentService.getAppointment("1")); // Check if it was added correctly
    }

    // Test case for adding a duplicate appointment
    @Test
    public void testAddDuplicateAppointment() {
        appointmentService.addAppointment(appointment1); // Add the first appointment
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment1); // Try to add the same appointment again
        });
        assertEquals("Appointment ID already exists", exception.getMessage()); // Check if the correct exception is thrown
    }

    // Test case for deleting an appointment
    @Test
    public void testDeleteAppointment() {
        appointmentService.addAppointment(appointment1); // Add the first appointment
        appointmentService.deleteAppointment("1"); // Delete the appointment
        assertNull(appointmentService.getAppointment("1")); // Check if it was deleted correctly
    }

    // Test case for deleting a non-existent appointment
    @Test
    public void testDeleteNonExistentAppointment() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("3"); // Try to delete an appointment that doesn't exist
        });
        assertEquals("Appointment ID not found", exception.getMessage()); // Check if the correct exception is thrown
    }

    // Test case for getting an appointment
    @Test
    public void testGetAppointment() {
        appointmentService.addAppointment(appointment1); // Add the first appointment
        Appointment retrievedAppointment = appointmentService.getAppointment("1"); // Retrieve the appointment
        assertNotNull(retrievedAppointment); // Check if the appointment is not null
        assertEquals("1", retrievedAppointment.getAppointmentId()); // Check the appointment ID
        assertEquals("Doctor's appointment", retrievedAppointment.getDescription()); // Check the description
        assertEquals("2024-12-01T10:00", retrievedAppointment.getDateTime()); // Check the date and time
    }
}
