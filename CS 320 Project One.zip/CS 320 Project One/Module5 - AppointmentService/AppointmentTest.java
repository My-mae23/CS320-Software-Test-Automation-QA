package module5;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Test;


public class AppointmentTest {

    // Helper method to create a Date object
    private Date createDate(int year, int month, int day) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        return calendar.getTime();
    }

    @Test
    void testValidAppointmentCreation() {
        // Create a future date for testing
        Date futureDate = createDate(2025, Calendar.JANUARY, 1);
        // Create a valid Appointment object
        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor's appointment");

        // Assert that the appointment ID is correctly set
        assertEquals("1234567890", appointment.getAppointmentId());
        // Assert that the appointment date is correctly set
        assertEquals(futureDate, appointment.getAppointmentDate());
        // Assert that the appointment description is correctly set
        assertEquals("Doctor's appointment", appointment.getDescription());
    }

    @Test
    void testInvalidAppointmentId() {
        // Create a future date for testing
        Date futureDate = createDate(2025, Calendar.JANUARY, 1);

        // Test with a null appointment ID
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor's appointment");
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid appointment ID", exception.getMessage());

        // Test with an appointment ID that is too long
        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor's appointment");
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid appointment ID", exception.getMessage());
    }

    @Test
    void testInvalidAppointmentDate() {
        // Create a past date for testing
        Date pastDate = createDate(2020, Calendar.JANUARY, 1);

        // Test with a past appointment date
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", pastDate, "Doctor's appointment");
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid appointment date", exception.getMessage());

        // Test with a null appointment date
        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", null, "Doctor's appointment");
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid appointment date", exception.getMessage());
    }

    @Test
    void testInvalidDescription() {
        // Create a future date for testing
        Date futureDate = createDate(2025, Calendar.JANUARY, 1);

        // Test with a null description
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, null);
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid description", exception.getMessage());

        // Test with a description that is too long
        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("1234567890", futureDate, "This description is way too long and exceeds the fifty characters limit.");
        });
        // Assert that the correct exception message is thrown
        assertEquals("Invalid description", exception.getMessage());
    }
}
