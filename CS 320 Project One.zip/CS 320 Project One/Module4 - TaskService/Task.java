package module4;

// This class will define the task object with the required fields and constraints.

public class Task {
    // Final variable to store the task ID.
    private final String taskId;
    // Variable to store the task name.
    private String name;
    // Variable to store the task description.
    private String description;

    // Constructor to initialize the Task object.
    public Task(String taskId, String name, String description) {
        // Check if taskId is null or its length is greater than 10.
        if (taskId == null || taskId.length() > 10) {
            // Throw an exception if the taskId is invalid.
            throw new IllegalArgumentException("Invalid task ID");
        }
        // Check if name is null or its length is greater than 20.
        if (name == null || name.length() > 20) {
            // Throw an exception if the name is invalid.
            throw new IllegalArgumentException("Invalid name");
        }
        // Check if description is null or its length is greater than 50.
        if (description == null || description.length() > 50) {
            // Throw an exception if the description is invalid.
            throw new IllegalArgumentException("Invalid description");
        }
        // Initialize the taskId, name, and description.
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

 // Method to get the task ID.
    public String getTaskId() {
        return taskId;
    }

    // Method to get the task name.
    public String getName() {
        return name;
    }

    // Method to set a new task name.
    public void setName(String name) {
        // Check if name is null or its length is greater than 20.
        if (name == null || name.length() > 20) {
            // Throw an exception if the name is invalid.
            throw new IllegalArgumentException("Invalid name");
        }
        // Set the new name.
        this.name = name;
    }

    // Method to get the task description.
    public String getDescription() {
        return description;
    }

    // Method to set a new task description.
    public void setDescription(String description) {
        // Check if description is null or its length is greater than 50.
        if (description == null || description.length() > 50) {
            // Throw an exception if the description is invalid.
            throw new IllegalArgumentException("Invalid description");
        }
        // Set the new description.
        this.description = description;
    }
}
