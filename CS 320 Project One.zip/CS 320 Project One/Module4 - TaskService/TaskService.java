package module4;

import java.util.HashMap;
import java.util.Map;

// This class will manage the tasks, including adding, updating, and deleting tasks.
public class TaskService {
    // Map to store tasks with their task IDs.
    private final Map<String, Task> tasks = new HashMap<>();

    // Method to add a new task
    public void addTask(Task task) {
        // Check if the task ID already exists.
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists");
        }
        // Add the task to the map.
        tasks.put(task.getTaskId(), task);
    }

    // Method to delete a task by task ID.
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    // Method to update the name of a task.
    public void updateTaskName(String taskId, String name) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setName(name);
        }
    }

    // Method to update the description of a task.
    public void updateTaskDescription(String taskId, String description) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setDescription(description);
        }
    }

    // Method to get a task by task ID.
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
