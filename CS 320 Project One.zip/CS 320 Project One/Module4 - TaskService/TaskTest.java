package module4;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
  
   // Test for creating a task and checking its details.
   @Test
   public void testTask() {
       Task task = new Task("12345", "Test Task", "This is a test description");
       assertEquals("12345", task.getTaskId());
       assertEquals("Test Task", task.getName());
       assertEquals("This is a test description", task.getDescription());
   }

   // Test for updating the task name.
   @Test
   public void testTaskNameUpdate() {
       Task task = new Task("12345", "Test Task", "This is a test description");
       task.setName("Updated Task");
       assertEquals("Updated Task", task.getName());
   }

   // Test for updating the task description.
   @Test
   public void testTaskDescriptionUpdate() {
       Task task = new Task("12345", "Test Task", "This is a test description");
       task.setDescription("Updated description");
       assertEquals("Updated description", task.getDescription());
   }

   // Test for creating a task with an invalid ID.
   @Test
   public void testTaskInvalidID() {
       assertThrows(IllegalArgumentException.class, () -> {
           new Task("12345678901", "Test Task", "This is a test description");
       });
   }

   // Test for creating a task with a null name.
   @Test
   public void testTaskInvalidName() {
       assertThrows(IllegalArgumentException.class, () -> {
           new Task("12345", null, "This is a test description");
       });
   }

   // Test for creating a task with a null description.
   @Test
   public void testTaskInvalidDescription() {
       assertThrows(IllegalArgumentException.class, () -> {
           new Task("12345", "Test Task", null);
       });
   }
}
