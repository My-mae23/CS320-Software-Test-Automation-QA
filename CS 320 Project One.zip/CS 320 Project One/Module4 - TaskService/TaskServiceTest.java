package module4;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
 
   // Test for adding a task and checking if it can be fetched correctly.
   @Test
   public void testAddTask() {
       TaskService taskService = new TaskService();
       Task task = new Task("12345", "Test Task", "This is a test description");
       taskService.addTask(task);
       assertEquals(task, taskService.getTask("12345"));
   }

   // Test for deleting a task and ensuring it is no longer retrievable.
   @Test
   public void testDeleteTask() {
       TaskService taskService = new TaskService();
       Task task = new Task("12345", "Test Task", "This is a test description");
       taskService.addTask(task);
       taskService.deleteTask("12345");
       assertNull(taskService.getTask("12345"));
   }

   // Test for updating a task and verifying the update is successful.
   @Test
   public void testUpdateTask() {
       TaskService taskService = new TaskService();
       Task task = new Task("12345", "Test Task", "This is a test description");
       taskService.addTask(task);
       Task updatedTask = new Task("12345", "Updated Task", "This is an updated description");
       taskService.updateTask(updatedTask);
       assertEquals(updatedTask, taskService.getTask("12345"));
   }

   // Test for getting a task and checking if the fetched task matches the added task.
   @Test
   public void testGetTask() {
       TaskService taskService = new TaskService();
       Task task = new Task("12345", "Test Task", "This is a test description");
       taskService.addTask(task);
       Task fetchedTask = taskService.getTask("12345");
       assertEquals(task, fetchedTask);
   }
}
